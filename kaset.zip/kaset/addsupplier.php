<?php


require 'function.php';

$conn = mysqli_connect("localhost", "root", "", "tokokaset");


if(isset($_POST["submit"]) ){
    
    $idsupplier            = $_POST['id_supplier'];
    $namasupplier          = htmlspecialchars($_POST['nama_supplier']);
    $alamat              = htmlspecialchars($_POST['alamat']);
    $no_telepon            = htmlspecialchars($_POST['no_telepon']);
    
        
        // include database connection file
    include_once("function.php");

        // Insert supplier data into table
    $result = mysqli_query($conn, "INSERT INTO supplier(id_supplier,nama_supplier,alamat,no_telepon) VALUES('$idsupplier','$namasupplier','$alamat','$no_telepon')");

        // Show message when supplier added
    echo "
    <script>
    alert('Data berhasil ditambahkan !!!!!')
    document.location.href = 'index.php?halaman=showsupplier';
    </script>
    ";

}




?>


<form action="" method="post">
  <div class="form-group">
    <label for="id_supplier">Id supplier</label>
    <input type="text" class="form-control" name="id_supplier" id="id_supplier" autofocus="">  
  </div>

  

<div class="form-group">
    <label for="nama_supplier">Nama supplier</label>
    <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" placeholder="masukkan nama supplier" autocomplete="off" maxlength="100">
</div>

  <div class="form-group">
    <label for="alamat">alamat</label>
    <input type="text" class="form-control" name="alamat" id="alamat" placeholder="masukkan alamat supplier" autocomplete="off" maxlength="20">
  </div>

   <div class="form-group">
    <label for="no_telepon">no_telepon</label>
    <input type="text" class="form-control" name="no_telepon" id="no_telepon" placeholder="masukkan no_telepon supplier" autocomplete="off" maxlength="20">
  </div>

  
<!--  -->
   
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>