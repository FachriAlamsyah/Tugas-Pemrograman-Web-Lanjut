<?php
require 'function.php';
$conn = mysqli_connect("localhost", "root", "", "tokokaset");

//ambil data id pelanggan
$id_pelanggan = $_GET["id_pelanggan"];

//query data berdasarkan id_pelanggan
$id_pelanggan = query("SELECT * FROM pelanggan WHERE id_pelanggan = $id_pelanggan")[0];


if(isset($_POST["submit"]) ){
    
    $id_pelanggan = $_POST['id_pelanggan'];
    $nama_pelanggan = htmlspecialchars($_POST['nama_pelanggan']);
    $alamat = htmlspecialchars($_POST['alamat']);
    $no_telepon = htmlspecialchars($_POST['no_telepon']);


    // update pelanggan data
    $result = mysqli_query($conn, "UPDATE pelanggan SET nama_pelanggan='$nama_pelanggan',alamat='$alamat',no_telepon='$no_telepon'  WHERE id_pelanggan=$id_pelanggan");

    // Redirect to homepage to display updated pelanggan in list
    // header("Location: index.php");
    
    echo "
 				<script>
 				alert('data berhasil diubah');
 				document.location.href = 'index.php?halaman=showpelanggan';
 				</script>
 		";


}
?>
<form action="" method="post">
  <div class="form-group">
    <label for="id_pelanggan">ID pelanggan</label>
    <input type="text" class="form-control" name="id_pelanggan" id="id_pelanggan" value="<?= $id_pelanggan["id_pelanggan"];?>" readonly>  
  </div>

  <div class="form-group">
    <label for="nama_pelanggan">Nama pelanggan</label>
    <input type="text" class="form-control" name="nama_pelanggan" id="nama_pelanggan" autofocus="" maxlength="10" autocomplete="off" value="<?= $id_pelanggan["nama_pelanggan"];?>">
  </div>

<div class="form-group">
    <label for="alamat">alamat</label>
    <input type="text" class="form-control" name="alamat" id="alamat" placeholder="masukkan alamat " autocomplete="off" maxlength="100" value="<?= $id_pelanggan["alamat"];?>">
</div>

  <div class="form-group">
    <label for="no_telepon">no_telepon</label>
    <input type="text" class="form-control" name="no_telepon" id="no_telepon" placeholder="masukkan no_telepon " autocomplete="off" maxlength="20" value="<?= $id_pelanggan["no_telepon"];?>">
  </div>

 
  
<!--  -->
   
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>