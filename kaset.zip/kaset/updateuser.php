<?php
require 'function.php';
$conn = mysqli_connect("localhost", "root", "", "tokokaset");

//ambil data id user
$id_user = $_GET["id_user"];

//query data berdasarkan id_user
$id_user = query("SELECT * FROM user WHERE id_user = $id_user")[0];


if(isset($_POST["submit"]) ){
    
    $id_user = $_POST['id_user'];
    $nama_user = htmlspecialchars($_POST['nama_user']);
    $alamat = htmlspecialchars($_POST['alamat']);
    $no_telepon = htmlspecialchars($_POST['no_telepon']);


    // update user data
    $result = mysqli_query($conn, "UPDATE user SET nama_user='$nama_user',alamat='$alamat',no_telepon='$no_telepon'  WHERE id_user=$id_user");

    // Redirect to homepage to display updated user in list
    // header("Location: index.php");
    
    echo "
 				<script>
 				alert('data berhasil diubah');
 				document.location.href = 'index.php?halaman=showuser';
 				</script>
 		";


}
?>
<form action="" method="post">
  <div class="form-group">
    <label for="id_user">ID user</label>
    <input type="text" class="form-control" name="id_user" id="id_user" value="<?= $id_user["id_user"];?>" readonly>  
  </div>

  <div class="form-group">
    <label for="nama_user">Nama user</label>
    <input type="text" class="form-control" name="nama_user" id="nama_user" autofocus="" maxlength="10" autocomplete="off" value="<?= $id_user["nama_user"];?>">
  </div>

<div class="form-group">
    <label for="alamat">alamat</label>
    <input type="text" class="form-control" name="alamat" id="alamat" placeholder="masukkan alamat " autocomplete="off" maxlength="100" value="<?= $id_user["alamat"];?>">
</div>

  <div class="form-group">
    <label for="no_telepon">no_telepon</label>
    <input type="text" class="form-control" name="no_telepon" id="no_telepon" placeholder="masukkan no_telepon " autocomplete="off" maxlength="20" value="<?= $id_user["no_telepon"];?>">
  </div>

 
  
<!--  -->
   
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>