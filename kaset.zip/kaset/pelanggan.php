<?php
require 'function.php';
$idpelanggan = query("SELECT * FROM pelanggan ORDER BY id_pelanggan ASC");
?>
<div class="panel panel-default">
  <div class="panel-heading">
   <h4 align="center">PARECETAMORE MUSIC STORE CUSTOMER DATA</h4>
  </div>


 <div class="row">
   <div class="panel-body">

    <form action="" method="post">


      <input type="text" name="keyword" class="form-control" size="50" autofocus placeholder="masukkan keyword pencarian" autocomplete="off">

      <button  type="submit" name="caripelanggan">Cari</button>

      <a href="index.php?halaman=addpelanggan" class="btn btn-outline-primary">Tambah pelanggan</a>
      <a class="btn btn-outline-primary" href="index.php?halaman=showpelanggan" role="button">Refresh</a>


    </form>
    <br>

    <div class="table-responsive">
      <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
          <tr>
            <th  class="align-middle text-center">No</th>
            <th class="align-middle text-center">Id pelanggan</th>
            <th class="align-middle text-center">Nama pelanggan</th>
            <th class="align-middle text-center">alamat</th>
            <th class="align-middle text-center">no_telepon</th>
            
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $i = 1; ?>
          <?php  foreach( $idpelanggan as $row) : ?>
            <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo $row['id_pelanggan']; ?></td>
              <td><?php echo $row['nama_pelanggan']; ?></td>
              <td><?php echo $row['alamat']; ?></td>
              <td><?php echo $row['no_telepon']; ?></td>
            

              <td>
                <button class="btn btn-primary"><i class="fa fa-edit "><a style="color: white;" href="index.php?halaman=updatepelanggan&id_pelanggan=<?= $row["id_pelanggan"] ?>"></i> Update</a></button> | 

                 <button class="btn btn-danger"><i class="fa fa-pencil"></i><a style="color: white;" href="index.php?halaman=deletepelanggan&id_pelanggan=<?= $row["id_pelanggan"]; ?>" onclick="return confirm('Anda yakin ingin menghapus data ini ???');"> Delete</button> 
              </td>


            </tr>
            <?php $i++; ?>
          <?php endforeach; ?>
        </tbody>
      </table>
      
    </div>
  </div>
</div>
</div>