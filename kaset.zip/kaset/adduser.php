<?php


require 'function.php';

$conn = mysqli_connect("localhost", "root", "", "tokokaset");


if(isset($_POST["submit"]) ){
    
    $iduser            = $_POST['id_user'];
    $namauser          = htmlspecialchars($_POST['nama_user']);
    $alamat              = htmlspecialchars($_POST['alamat']);
    $no_telepon            = htmlspecialchars($_POST['no_telepon']);
    
        
        // include database connection file
    include_once("function.php");

        // Insert user data into table
    $result = mysqli_query($conn, "INSERT INTO user(id_user,nama_user,alamat,no_telepon) VALUES('$iduser','$namauser','$alamat','$no_telepon')");

        // Show message when user added
    echo "
    <script>
    alert('Data berhasil ditambahkan !!!!!')
    document.location.href = 'index.php?halaman=showuser';
    </script>
    ";

}




?>


<form action="" method="post">
  <div class="form-group">
    <label for="id_user">Id user</label>
    <input type="text" class="form-control" name="id_user" id="id_user" autofocus="">  
  </div>

  

<div class="form-group">
    <label for="nama_user">Nama user</label>
    <input type="text" class="form-control" name="nama_user" id="nama_user" placeholder="masukkan nama user" autocomplete="off" maxlength="100">
</div>

  <div class="form-group">
    <label for="alamat">alamat</label>
    <input type="text" class="form-control" name="alamat" id="alamat" placeholder="masukkan alamat user" autocomplete="off" maxlength="20">
  </div>

   <div class="form-group">
    <label for="no_telepon">no_telepon</label>
    <input type="text" class="form-control" name="no_telepon" id="no_telepon" placeholder="masukkan no_telepon user" autocomplete="off" maxlength="20">
  </div>

  
<!--  -->
   
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>