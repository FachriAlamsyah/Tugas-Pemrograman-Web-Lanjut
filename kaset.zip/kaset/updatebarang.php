<?php
require 'function.php';
$conn = mysqli_connect("localhost", "root", "", "tokokaset");

//ambil data id barang
$id_barang = $_GET["id_barang"];

//query data berdasarkan id_barang
$id_barang = query("SELECT * FROM barang WHERE id_barang = $id_barang")[0];


if(isset($_POST["submit"]) ){
    
    $id_barang = $_POST['id_barang'];
    $nama_barang = htmlspecialchars($_POST['nama_barang']);
    $genre = htmlspecialchars($_POST['genre']);
    $tahun = htmlspecialchars($_POST['tahun']);
        $idsup = htmlspecialchars($_POST['id_user']);


    // update user data
    $result = mysqli_query($conn, "UPDATE barang SET nama_barang='$nama_barang',genre='$genre',tahun='$tahun',id_user='$idsup'  WHERE id_barang=$id_barang");

    // Redirect to homepage to display updated user in list
    // header("Location: index.php");
    
    echo "
 				<script>
 				alert('data berhasil diubah');
 				document.location.href = 'index.php?halaman=showbarang';
 				</script>
 		";


}
?>
<form action="" method="post">
  <div class="form-group">
    <label for="id_barang">ID barang</label>
    <input type="text" class="form-control" name="id_barang" id="id_barang" value="<?= $id_barang["id_barang"];?>" readonly>  
  </div>

  <div class="form-group">
    <label for="nama_barang">Nama barang</label>
    <input type="text" class="form-control" name="nama_barang" id="nama_barang" autofocus="" maxlength="10" autocomplete="off" value="<?= $id_barang["nama_barang"];?>">
  </div>

<div class="form-group">
    <label for="genre">genre</label>
    <input type="text" class="form-control" name="genre" id="genre" placeholder="masukkan genre " autocomplete="off" maxlength="100" value="<?= $id_barang["genre"];?>">
</div>

  <div class="form-group">
    <label for="tahun">tahun</label>
    <input type="date" class="form-control" name="tahun" id="tahun" placeholder="masukkan tahun " autocomplete="off" maxlength="20" value="<?= $id_barang["tahun"];?>">
  </div>

 
  
<!--  -->
   <div class="form-group">
    <label for="id_user" class="col-sm-2 col-form-label">Kode user</label>
    <select name="id_user" class="form-control" id="id_user">
        <?php
$conn = mysqli_connect("localhost", "root", "", "tokokaset");

          $result = mysqli_query($conn, "SELECT * FROM user ORDER BY id_user");
          while ($row = mysqli_fetch_assoc($result)) 
          {
            echo "<option>$row[id_user] $row[nama_user]</option>";
          }
        ?>
    </select>
  </div>
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>