<?php
require 'function.php';
$idbarang = query("SELECT * FROM barang ORDER BY id_barang ASC");
?>
<div class="panel panel-default">
  <div class="panel-heading">
   <h4 align="center">PARECETAMORE MUSIC STORE INVENTORY</h4>
  </div>


 <div class="row">
   <div class="panel-body">

    <form action="" method="post">


      <input type="text" name="keyword" class="form-control" size="50" autofocus placeholder="masukkan keyword pencarian" autocomplete="off">

      <button  type="submit" name="caribarang">Cari</button>

      <a href="index.php?halaman=addbarang" class="btn btn-success">Tambah Barang</a>
      <a class="btn btn-light" href="index.php?halaman=showbarang" role="button">Refresh</a>


    </form>
    <br>

    <div class="table-responsive">
      <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
          <tr>
            <th  class="align-middle text-center">No</th>
            <th class="align-middle text-center">Id barang</th>
            <th class="align-middle text-center">Nama Barang</th>
            <th class="align-middle text-center">Genre</th>
            <th class="align-middle text-center">Tahun</th>
            <th class="align-middle text-center">Id User</th>
            
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $i = 1; ?>
          <?php  foreach( $idbarang as $row) : ?>
            <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo $row['id_barang']; ?></td>
              <td><?php echo $row['nama_barang']; ?></td>
              <td><?php echo $row['genre']; ?></td>
              <td><?php echo $row['tahun']; ?></td>
              <td><?php echo $row['id_user']; ?></td>
            

              <td>
                <button class="btn btn-primary"><i class="fa fa-edit "><a style="color: white;" href="index.php?halaman=updatebarang&id_barang=<?= $row["id_barang"] ?>"></i> Update</a></button> |
                
                <button class="btn btn-danger"><i class="fa fa-pencil"></i><a style="color: white;" href="index.php?halaman=deletebarang&id_barang=<?= $row["id_barang"]; ?>" onclick="return confirm('Anda yakin ingin menghapus data ini ???');"> Delete</button>
              </td>


            </tr>
            <?php $i++; ?>
          <?php endforeach; ?>
        </tbody>
      </table>
      
    </div>
  </div>
</div>
</div>