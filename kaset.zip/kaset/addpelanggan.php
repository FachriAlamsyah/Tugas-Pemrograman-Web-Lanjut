<?php


require 'function.php';

$conn = mysqli_connect("localhost", "root", "", "tokokaset");


if(isset($_POST["submit"]) ){
    
    $idpelanggan            = $_POST['id_pelanggan'];
    $namapelanggan          = htmlspecialchars($_POST['nama_pelanggan']);
    $alamat              = htmlspecialchars($_POST['alamat']);
    $no_telepon            = htmlspecialchars($_POST['no_telepon']);
    
        
        // include database connection file
    include_once("function.php");

        // Insert pelanggan data into table
    $result = mysqli_query($conn, "INSERT INTO pelanggan(id_pelanggan,nama_pelanggan,alamat,no_telepon) VALUES('$idpelanggan','$namapelanggan','$alamat','$no_telepon')");

        // Show message when pelanggan added
    echo "
    <script>
    alert('Data berhasil ditambahkan !!!!!')
    document.location.href = 'index.php?halaman=showpelanggan';
    </script>
    ";

}




?>


<form action="" method="post">
  <div class="form-group">
    <label for="id_pelanggan">Id pelanggan</label>
    <input type="text" class="form-control" name="id_pelanggan" id="id_pelanggan" autofocus="">  
  </div>

  

<div class="form-group">
    <label for="nama_pelanggan">Nama pelanggan</label>
    <input type="text" class="form-control" name="nama_pelanggan" id="nama_pelanggan" placeholder="masukkan nama pelanggan" autocomplete="off" maxlength="100">
</div>

  <div class="form-group">
    <label for="alamat">alamat</label>
    <input type="text" class="form-control" name="alamat" id="alamat" placeholder="masukkan alamat pelanggan" autocomplete="off" maxlength="20">
  </div>

   <div class="form-group">
    <label for="no_telepon">no_telepon</label>
    <input type="text" class="form-control" name="no_telepon" id="no_telepon" placeholder="masukkan no_telepon pelanggan" autocomplete="off" maxlength="20">
  </div>

  
<!--  -->
   
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>