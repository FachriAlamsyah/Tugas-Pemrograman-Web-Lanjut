<?php
$idpelanggan = $_GET['id_pelanggan'];

$conn = mysqli_connect("localhost","root","","tokokaset");
$result = mysqli_query($conn,"DELETE FROM pelanggan WHERE id_pelanggan=$idpelanggan");

echo "<script>
		alert('data berhasil dihapus');
		document.location.href ='index.php?halaman=showpelanggan';
		</script>
";

?>