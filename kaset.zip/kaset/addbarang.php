<?php


require 'function.php';

$conn = mysqli_connect("localhost", "root", "", "tokokaset");


if(isset($_POST["submit"]) ){
    
    $idbarang            = $_POST['id_barang'];
    $namabarang          = htmlspecialchars($_POST['nama_barang']);
    $genre              = htmlspecialchars($_POST['genre']);
    $tahun            = htmlspecialchars($_POST['tahun']);
    
    $iduser             = htmlspecialchars($_POST['id_user']);
        
        // include database connection file
    include_once("function.php");

        // Insert user data into table
    $result = mysqli_query($conn, "INSERT INTO barang(id_barang,nama_barang,genre,tahun,id_user) VALUES('$idbarang','$namabarang','$genre','$tahun','$iduser')");

        // Show message when user added
    echo "
    <script>
    alert('Data berhasil ditambahkan !!!!!')
    document.location.href = 'index.php?halaman=showbarang';
    </script>
    ";

}




?>


<form action="" method="post">
  <div class="form-group">
    <label for="id_barang">Id barang</label>
    <input type="text" class="form-control" name="id_barang" id="id_barang" autofocus="">  
  </div>

  

<div class="form-group">
    <label for="nama_barang">Nama barang</label>
    <input type="text" class="form-control" name="nama_barang" id="nama_barang" placeholder="masukkan nama barang" autocomplete="off" maxlength="100">
</div>

  <div class="form-group">
    <label for="genre">genre</label>
    <input type="text" class="form-control" name="genre" id="genre" placeholder="masukkan genre barang" autocomplete="off" maxlength="20">
  </div>

   <div class="form-group">
    <label for="tahun">tahun</label>
    <input type="date" class="form-control" name="tahun" id="tahun" placeholder="masukkan tahun barang" autocomplete="off" maxlength="20">
  </div>

  
<!--  -->
   <div class="form-group">
    <label for="id_user" class="col-sm-2 col-form-label">id user</label>
    <select name="id_user" class="form-control" id="id_user">
        <?php
          $conn = mysqli_connect("localhost", "root", "", "tokokaset");
          $result = mysqli_query($conn, "SELECT * FROM user ORDER BY id_user");
          while ($row = mysqli_fetch_assoc($result)) 
          {
            echo "<option>$row[id_user] $row[nama_user]</option>";
          }
        ?>
    </select>
  </div>
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>